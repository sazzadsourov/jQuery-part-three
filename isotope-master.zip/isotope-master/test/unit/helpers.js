( function() {

'use strict';

// ----- default layout mode ----- //
Isotope.defaults.layoutMode = 'fitRows';

} )();
